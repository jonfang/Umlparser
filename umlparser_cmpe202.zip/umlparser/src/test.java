class Hello1 {
    private String str ;
    public String getStr() { return this.str ; }
    public void   setStr(String value) { this.str = value ; }
}