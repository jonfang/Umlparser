 

public class C2 {
    
    public void test( A2 a2 ) {
        // call a2 methods
    }
    
}
 
