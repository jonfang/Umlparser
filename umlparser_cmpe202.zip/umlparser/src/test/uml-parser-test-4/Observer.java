
public interface Observer {
 
	public abstract void update();
}
 
